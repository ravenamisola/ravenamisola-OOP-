﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity4_Form
{
    class HappyBirthday
    {
        public string GetMessage(String firstname)
        {
            return "Happy Birthday" + firstname;
        }
    }
}
