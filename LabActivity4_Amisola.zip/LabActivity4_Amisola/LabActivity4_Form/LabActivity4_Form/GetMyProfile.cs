﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity4_Form
{
    class GetMyProfile
    {
        public string GetMessage(String firstname)
        {
            return "Hello" +"\t" + firstname + "\n" + "DateTime of Birth" + "\t" + "November 10, 1998" + "\n" + "Course" + "\t" + "BSCS" + "\n" + "Year" + "\t" + "II" + "\n" + "Section" + "\t" + "B" ;
        }
    }
}
