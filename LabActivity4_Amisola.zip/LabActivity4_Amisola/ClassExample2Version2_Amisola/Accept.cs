﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassExample2Version2_Amisola
{
    class Accept
    {
        public string firstcolor, secondcolor;
        public void AcceptDetails()
        {
            System.Console.Write(" Firstcolor :\t");
              firstcolor = System.Console.ReadLine();
            System.Console.Write(" Secondcolor :\t");
            secondcolor = System.Console.ReadLine();
        }
    }
}
