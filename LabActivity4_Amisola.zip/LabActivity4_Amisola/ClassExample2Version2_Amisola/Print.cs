﻿

using ClassExample2Version2_Amisola;

class Print
    {
        public void PrintDetails()
        {
            Accept a = new Accept();
            a.AcceptDetails();

            System.Console.Write("The colors of the car are:" +" " + a.firstcolor  + " "+"and" + " "+ a.secondcolor );
           
        }
}
