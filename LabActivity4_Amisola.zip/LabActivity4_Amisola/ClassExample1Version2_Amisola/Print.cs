﻿using ClassExample1Version2_Amisola;

    class Print
    {

        public void PrintDetails(string firstname,string lastname)
        {
            Accept a = new Accept();
            System.Console.Write("Hello " + firstname + " " + lastname + "!!!\nYou have Created Classes in OOP");
            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
        }
}
