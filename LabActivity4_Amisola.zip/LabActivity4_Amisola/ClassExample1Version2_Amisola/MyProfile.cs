﻿

namespace ClassExample1Version2_Amisola
{
    class MyProfile
    {

        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t\t\tP R O F I L E\n");
            System.Console.WriteLine("Name\t:\t\tRaven R Amisola\n");
            System.Console.WriteLine("Birtday\t:\t\tNovember 10, 1998\n");
            System.Console.WriteLine("Couse\t:\t\tBS Computer Science Major in Network" + " and Data Communication\n");
            System.Console.WriteLine("Year\t:\t\t2nd Year\n");
            System.Console.WriteLine("Section\t:\t\tB\n");
            System.Console.ReadLine();
        }
    }
}
