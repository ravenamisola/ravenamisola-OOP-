﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabActivity4_Amisola
{
    class ClassExample1_Amisola
    {
        static void Main(string[] args)
        {
        
                Print p = new Print();
                p.PrintDetails();
                Console.ReadLine();
            

        }
    }
}
