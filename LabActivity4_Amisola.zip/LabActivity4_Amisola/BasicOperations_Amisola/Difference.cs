﻿

    class Difference
    {

        public double getDifference(double a, double b)
        {
            double c = a - b;
            return c;
        }
    }

