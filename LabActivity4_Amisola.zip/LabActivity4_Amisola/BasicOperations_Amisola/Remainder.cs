﻿
    class Remainder
    {
        public double getRemainder(double a, double b)
        {
            double c = a % b;
            return c;
        }
}
