﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Amisola
{
    class Program
    {
        static void Main(string[] args)
        {



            Declarevar dv = new Declarevar();
            dv.Declaringvar();
            Console.ReadKey();
        }
    }
}
