﻿ class Input
    {
        public static double num1, num2;
        public double number1()
        {
            System.Console.Write("Input first number: ");
            num1 = System.Convert.ToDouble(System.Console.ReadLine());
            return num1;
        }
        public double number2()
        {
            System.Console.Write("Input second number: ");
            num2 = System.Convert.ToDouble(System.Console.ReadLine());
            return num2;
        }
}
